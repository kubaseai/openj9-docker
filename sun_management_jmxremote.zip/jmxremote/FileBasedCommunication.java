package sun.management.jmxremote;

import java.io.Closeable;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.io.StringWriter;
import java.io.SyncFailedException;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.nio.ByteBuffer;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.channels.SocketChannel;
import java.nio.file.Files;
import java.util.Random;
import java.util.UUID;

/**
 * This class emulated Socket using two files: .IN (InputStream from server
 * point of view) and .OUT (OutputStream from server point of view).
 * For strong consistency there are used file locks and fsync.
 */
public class FileBasedCommunication extends Socket implements Closeable, AutoCloseable {
	
	/* When writing after payload there is a "cookie" placed for the remote peer,
	 * so after reading payload remote peer can confirm reading. Once confirmed
	 * we both can move to beginning of file. We cannot infinitely go to the right,
	 * because we would eat all filesystem space, we need to reset position.
	 * "Cookie" value is monotonic negative starting with -2.*/
	private final static int RESET_REQUEST_INITIAL_VAL = -2;
	/* We do not use sophisticated IPC mechanism for synchronization and concurrency,
	 * we just sleep. */
	private final static int SHORT_SLEEP_MS = 15;
	private final static int MEDIUM_SLEEP_MS = 150;
	/* Please use with: mount -t tmpfs none /tmp/.jmx */
	private final static String JMX_DIR_NAME = ".jmx";
	private RandomAccessFile fileIn = null;
	private RandomAccessFile fileOut = null;
	private File pathIn = null;
	private File pathOut = null;
	/* this is socket timeout - when no new content arrives while reading
	 * after exceeding timeout we throw SocketTimeoutException */
	private volatile int timeout = 60000;
	/* this is counter for generating "cookies" */
	private int ResetRequestByServer = RESET_REQUEST_INITIAL_VAL;
	private FileInStream inp = new FileInStream();
	private FileOutStream out = new FileOutStream();
	/* this is for server in case we want to kill inactive files */
	private long lastActiveTs = System.currentTimeMillis();
	/* this is used to minimize tracing output */
	volatile private String lastMsg = null;
	/* this is used to generate random sleep values (to avoid deadlocks)*/
	private static Random rnd = new Random();
			
	private static boolean trace = "true".equalsIgnoreCase(System.getProperty(FileBasedCommunication.class.getName()+".trace"));
	private static String acceptDir = System.getProperty(FileBasedCommunication.class.getName()+".acceptDir",
		System.getProperty("java.io.tmpdir","/tmp") + "/" + JMX_DIR_NAME);
	
	/*
	 * Constructor to be called by the server
	 */
	public FileBasedCommunication(File f) throws IOException {
		if (f.getName().endsWith(".IN")) {
			this.pathIn = f;
			String fn = f.getAbsolutePath();
			this.pathOut = new File(fn.substring(0, fn.length()-3) + ".OUT");
		}
		else if (f.getName().endsWith(".OUT")) {
			this.pathOut = f;
			String fn = f.getAbsolutePath();
			this.pathIn = new File(fn.substring(0, fn.length()-4) + ".IN");
		}
		trace(0, "ctor() server side");
		openFiles();
	}
	
	/*
	 * Constructor to be called by the client
	 */
	public FileBasedCommunication(String acceptDir) throws IOException {
		String uuid = UUID.randomUUID().toString();
		this.pathIn = new File(acceptDir, uuid+".OUT");
		this.pathOut = new File(acceptDir, uuid+".IN");
		for (File path: new File[] { pathIn, pathOut }) {
			Files.createDirectories(path.getParentFile().toPath());
			path.createNewFile();
			path.setReadable(true);
			path.setWritable(true);
		}
		trace(0, "ctor() client side");
		openFiles();
	}
	
	/*
	 * We must prevent race between server and client for .OUT file
	 */
	private void openFiles() throws SyncFailedException, IOException {
		long start = System.currentTimeMillis();
		while (true) {
			if (pathIn.exists() && pathOut.exists())
				break;
			try {
				Thread.sleep(SHORT_SLEEP_MS);
			}
			catch (InterruptedException e) {
				throw new IOException("Interrupted waiting for files to appear");
			}
			if (timeout > 0 && start + timeout < System.currentTimeMillis()) {
				trace(0, "No file(s) to open", true);
				throw new SocketTimeoutException();
			}
		}
		fileIn = new RandomAccessFile(this.pathIn, "rw");
		fileOut = new RandomAccessFile(this.pathOut, "rw");		
	}

	public final static File getProcessCommunicationDir() {
		File jmx = new File(acceptDir);
		return new File(jmx, ManagementFactory.getRuntimeMXBean().getName()); /* last part is process@host */
	}
	
	private final static int getRandomFromRange(int start, int end) {
		return start + rnd.nextInt(end - start);
	}
	
	private void trace(int kind, String msg) {
		trace(kind, msg, false);
	}
	
	private void trace(int kind, String msg, boolean force) {
		if (trace || force) {
			String message = "["+(kind==0 ? pathIn.getAbsolutePath() : pathOut.getAbsolutePath())+"] "+msg;
			if (!message.equals(lastMsg)) {
				System.out.println(message);
				lastMsg = message;
			}
		}
	}
		
	private static String exception2string(Throwable t) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		t.printStackTrace(pw);
		pw.flush();
		sw.flush();
		return sw.toString();
	}
	
	private void deleteFiles() {
		for (File path: new File[] { pathIn, pathOut }) {
			try {
				if (Files.deleteIfExists(path.toPath()))
					trace(0, "File "+path.getName()+" deleted");
			}
			catch (Exception exc) {}
		}
	}
	
	private int getSleepShiftTimeMillis() {
		return getRandomFromRange(SHORT_SLEEP_MS, MEDIUM_SLEEP_MS);
	}
	
	private FileLock getLock(RandomAccessFile file, Long from, long length, boolean exclusive, String caller) throws IOException {
		FileLock lock = null;
		if (from==null)
			from = file.getFilePointer();
		int i=0;
		while (true) {
			i++;
			try {
				lock = file.getChannel().tryLock(from, length, !exclusive);
				if (lock!=null)
					break;
			}
			catch (OverlappingFileLockException ov) {
				if (i >= 10)
					trace(file==fileIn ? 0 : 1, "l0ck concurrency ("+from+"-"+(from+length)+") "
						+i+" "+(exclusive ? "exc" : "") + " in "+caller, true);
				/** In case we have reader and writer in the same JVM.
				  * Probably it can happen only in unit tests. */
				try {
					Thread.sleep(getSleepShiftTimeMillis());
				}
				catch (InterruptedException e) {
					throw new IOException("Interrupted waiting for l0ck");
				}
			}
			catch (IOException io) {
				if ("Resource deadlock avoided".equals(io.getMessage())) {
					if (i >= 10)
						trace(file==fileIn ? 0 : 1, "lock concurrency ("+from+"-"+(from+length)+") "
							+i+" "+(exclusive ? "exc" : "") + " in "+caller, true);
					try {
						Thread.sleep(getSleepShiftTimeMillis());
					}
					catch (InterruptedException e) {
						throw new IOException("Interrupted waiting for lock");
					}
				}
				else
					throw io;
			}
		}
		return lock;
	}
	
	private int fileReadInt(RandomAccessFile file) throws IOException {
		ByteBuffer bb = ByteBuffer.allocate(4);
		int cnt = 0;
		while (cnt < 4) {
			int n = file.getChannel().read(bb);
			if (n==-1)
				throw new EOFException();
			else if (n==0) {
				try {
					Thread.sleep(SHORT_SLEEP_MS);
				}
				catch (InterruptedException ie) {
					throw new IOException("Interrupted fileReadInt");
				}
			}
			else
				cnt += n;
		}
		bb.flip();
		return bb.asIntBuffer().get(0);
	}
	
	private void fileWriteInt(RandomAccessFile file, int v) throws IOException {
		ByteBuffer bb = ByteBuffer.allocate(4);
		bb.asIntBuffer().put(v);
		if (file.getChannel().write(bb)!=4)
			throw new IOException("WriteInt size not matched");
	}
	
	private void fileWriteBytes(RandomAccessFile file, byte[] buff, int off, int len) throws IOException {
		if (len > 0) {
			ByteBuffer bb = ByteBuffer.wrap(buff, off, len);
			if (file.getChannel().write(bb)!=len)
				throw new IOException("WriteBytes size not matched");
		}
	}
	
	private void fileReadBytes(RandomAccessFile file, byte[] buff, int off, int len) throws IOException {
		ByteBuffer bb = ByteBuffer.wrap(buff, off, len);
		int cnt = 0;
		while (cnt < len) {
			int n = file.getChannel().read(bb);
			if (n==-1)
				throw new EOFException();
			else if (n==0) {
				try {
					Thread.sleep(SHORT_SLEEP_MS);
				}
				catch (InterruptedException ie) {
					throw new IOException("Interrupted fileReadBytes");
				}
			}
			else
				cnt += n;
		}			
	}
	
	private void fsync(RandomAccessFile file, boolean md) throws IOException {
		file.getChannel().force(md);		
	}
	
	public class FileInStream extends InputStream {
		
		private byte[] buff = null;
		private int shift = 0;
		private long transferred = 0;
		private Object mutexRead = new Object();
		private long lastFullReadPos = 0;

		@Override
		public int available() {
			synchronized(mutexRead) {
				return _available();				
			}
		}
		
		@Override
		public long skip(long n) throws IOException {
			trace(0, "skip "+n);
			return read(new byte[(int)n]);
		}
		
		private int _available() {
			return buff==null ? 0 : buff.length - shift;			
		}
		
		@Override
		public int read(byte[] b, int off, int len) throws IOException {
			long start = System.currentTimeMillis();
			while (true) {
				int size = _read(b, off, len);
				long dt = System.currentTimeMillis() - start;
				if (size==-1 || size > 0) {					
					return size;
				}
				else if (dt > 30000) {
					trace(0, "  read: waiting for read over 30s");
				}
			
				try {
					Thread.sleep(SHORT_SLEEP_MS);
				} 
				catch (InterruptedException e) {
					throw new IOException("Interrupted read");
				}
				if (timeout!=0 && start + timeout < System.currentTimeMillis()) {
					trace(0, "  read: timeout on read");
					throw new SocketTimeoutException();
				}
			}
		}
		
		public int _read(byte[] b, int off, int len) throws IOException {
			trace(0, "+ read request: "+len);
			synchronized(mutexRead) {
				if (fileIn==null)
					return -1;
				int available = _available();
				if (available > 0) {
					/* We must read all written payload, so we buffer unused part
					 * for later use. Now let's use that buffer. */
					int toRead = Math.min(len, available);
					System.arraycopy(buff, shift, b, off, toRead);
					shift += toRead;
					if (shift >= buff.length) {
						buff = null;
						shift = 0;
					}
					trace(0, "- read response: "+toRead);
					return toRead;
				}
				
				long fp0 = fileIn.getFilePointer();
				FileLock lock = null;
				try {
					lock = getLock(fileIn, null, 4, false, "reader size");
					lastActiveTs = System.currentTimeMillis();
					long fileEnd = fileIn.length();
					if (lastFullReadPos > 0 && lastFullReadPos < fileEnd) {
						Integer val = null;
						if (fileEnd - lastFullReadPos >= 4) {
							val = fileReadInt(fileIn);
							fileIn.seek(fp0);
						}
						trace(0, ". read: other data at "+lastFullReadPos+"-"+fileEnd+(val!=null ? " int="+val : ""));
					}
					int size = fileReadInt(fileIn);
					lock.release();
					lock = null;
					if (size == -1) {
						trace(0, "- Reader: EOT");
						buff = null;
						return size;
					}
					else if (size < -1 && fileIn.getFilePointer() == 4) {
						/* Reader did read own reset confirmation, rewinding to 0. */
						fileIn.seek(0);
						return 0; /* EAGAIN */
					}
					else if (size < -1) {
						/* should not happen (tm) */
						throw new IOException("Inconsistent stream processing while reading");
					}
					
					/* This tracing is in case size is very big due to inconsistent read and we cause OOM.
					 * At least we know the reason - corrupted size.
					 */
					if (trace)
						trace(0, "  read: "+size+" start at "+fileIn.getFilePointer());
					
					buff = new byte[size];
					long lockMax = fileIn.getFilePointer() + size + 4;
					lock = getLock(fileIn, 0L, lockMax, false, "reader buff & ack");
					fileReadBytes(fileIn, buff, shift=0, size);
					int toReturn = Math.min(len, size);
					System.arraycopy(buff, shift, b, off, toReturn);
					shift += toReturn;
					transferred += toReturn;
					
					int seq = fileReadInt(fileIn);
					long fp = fileIn.getFilePointer();
					long seekEnd = fileIn.length();
					if (fp == seekEnd) {
						/* all writes consumed by us, let's confirm it to the peer */
						lastFullReadPos = fp;
						fileIn.seek(0);
						fileWriteInt(fileIn, seq);
						fsync(fileIn, true);
						fileIn.seek(fp=0);
					}
					else
						lastFullReadPos = 0;
					lock.release();
					lock = null;
					
					if (trace)
						trace(0, "- read: "+toReturn+" (streamed="+transferred+"), peer seq is "+seq+", now at "+fp);
										
					return toReturn;
				}
				catch (EOFException eof) {
					if (transferred > 0 && !pathIn.exists()) { /* deleted */
						trace(0, "- read: EOF EOT, started from "+fp0+", now at "+fileIn.getFilePointer());
						return -1;
					}
					trace(0, "- read: EOF EAGAIN, started from "+fp0+", now at "+fileIn.getFilePointer());
					fileIn.seek(fp0);
					return 0;
				}
				catch (Throwable t) {
					trace(0, "! read: exception "+exception2string(t), true);
					throw t;
				}
				finally {
					if (lock!=null) {
						try {
							lock.release();
						}
						catch (Exception e) {
							trace(0, "! read: exception unlocking "+exception2string(e), true);
						}
					}
				}
			}
		}
		
		@Override
		public int read(byte[] b) throws IOException {
			return read(b, 0, b.length);
		}

		@Override
		public int read() throws IOException {
			byte[] b = new byte[1];
			int cnt = read(b);
			return cnt > 0 ? b[0] : -1;
		}
		
		@Override
		public void close() throws IOException {
			trace(0, "Reader: closing");
			synchronized(mutexRead) {
				fileIn = null;				
			}
		}
	}
	
	public class FileOutStream extends OutputStream {
		
		private long transferred = 0;
		private Object mutexWrite = new Object();

		@Override
		public void close() throws IOException {
			trace(1, "Writer: closing");
			_write(new byte[0], 0, -1);
			synchronized(mutexWrite) {
				fileOut = null;				
			}
		}

		/*
		 * If peer confirmed out last write, we both can rewind to beginning of file
		 */
		private Boolean _checkAckForLastWrite(boolean locked) throws IOException {
			long fp = fileOut.getFilePointer();
			FileLock lock = null;
			if (fp > 0) {
				try {
					if (locked)
						lock = getLock(fileOut, 0L, 4L, false, "writer check ack");
					fileOut.seek(0);
					int ack = fileReadInt(fileOut);
					if (ack == ResetRequestByServer) {
						fileOut.seek(0);
						return true;
					}
					else {
						if (ack > -1 && ack != ResetRequestByServer) {
							trace(1, "Invalid ack="+ack+", expected="+ResetRequestByServer);
						}
						fileOut.seek(fp);
						return false;
					}
				}
				finally {
					if (lock!=null) {
						try {
							lock.release();
						}
						catch (Exception e) {}
					}
				}
			}
			return null;
		}

		private Boolean checkAckForLastWrite() throws IOException {
			for (boolean b : new boolean[] { false, true }) { 
				Boolean result = _checkAckForLastWrite(b);
				if (result == null || Boolean.TRUE.equals(result))
					return result;
			}
			try {
				Thread.sleep(SHORT_SLEEP_MS);
			} 
			catch (InterruptedException e) {}
			return _checkAckForLastWrite(true);
		}
		
		private int getNextResetRequestCounter() {
			if (ResetRequestByServer == Integer.MIN_VALUE)
				ResetRequestByServer = RESET_REQUEST_INITIAL_VAL;
			return --ResetRequestByServer;
		}
		
		@Override
		public void write(byte[] b, int off, int len) throws IOException {
			if (fileOut==null)
				throw new IOException("File OUT is null");
			if (b==null)
				throw new NullPointerException();
			if (len <= 0 || b.length == 0)
				return;			
			_write(b, off, len);
		}
		
		public void _write(byte[] b, int off, int len) throws IOException {
			trace(1, "+ write: "+len+" start at "+fileOut.getFilePointer());
			synchronized(mutexWrite) {
				FileLock lock = null;
				try {
					lastActiveTs = System.currentTimeMillis();
					Boolean ack = checkAckForLastWrite();
					trace(1, "  write: previously acked by peer: "+ack);
					lock = getLock(fileOut, null, len+8, true, "writer");
					fileWriteInt(fileOut, len);
					fileWriteBytes(fileOut, b, off, len);
					fileWriteInt(fileOut, getNextResetRequestCounter());
					long currPos = fileOut.getFilePointer();
					long maxPos = fileOut.length();
					for (long p = currPos; p < maxPos; p+=4) {
						fileWriteInt(fileOut, 0);
					}
					fileOut.setLength(currPos); /* truncate file, because we all reset position */
					fsync(fileOut, true);
					transferred += len;
					lock.release();
					lock = null;
					
					if (trace)
						trace(1, "- write: "+len+" (streamed="+transferred+") with seq "+ResetRequestByServer+
								", now at "+fileOut.getFilePointer());					
				}
				catch (Throwable t) {
					trace(0, "! write: exception "+exception2string(t), true);
					throw t;
				}
				finally {
					if (lock!=null) {
						try {
							lock.release();
						}
						catch (Exception e) {
							trace(0, "! write: exception unlocking "+exception2string(e), true);
						}
					}
				}
			}
		}

		@Override
		public void write(byte[] b) throws IOException {
			write(b, 0, b.length);
		}

		@Override
		public void write(int data) throws IOException {
			byte[] b = new byte[1];
			b[0] = (byte)(data & 0xff);
			write(b, 0, 1);
		}
	}

	@Override
	public void bind(SocketAddress bindpoint) throws IOException {
		trace(0, "bind to "+bindpoint);
	}

	@Override
	public void close() throws IOException {
		try {
			getOutputStream().close();
		}
		catch (Exception e) {}
		try {
			getInputStream().close();
		}
		catch (Exception e) {}
		deleteFiles();
	}

	@Override
	public void connect(SocketAddress endpoint, int timeout) throws IOException {
		trace(0, "connect to "+endpoint+" timeout "+timeout);
	}

	@Override
	public void connect(SocketAddress endpoint) throws IOException {
		trace(0, "connect to "+endpoint);
	}

	@Override
	public SocketChannel getChannel() {
		trace(0, "getChannel requested but not supported", true);
		throw new RuntimeException("not supported");
	}

	@Override
	public InetAddress getInetAddress() {
		return InetAddress.getLoopbackAddress();
	}

	@Override
	public InputStream getInputStream() throws IOException {
		return inp;
	}

	@Override
	public boolean getKeepAlive() throws SocketException {
		return false;
	}

	@Override
	public InetAddress getLocalAddress() {
		return InetAddress.getLoopbackAddress();
	}

	@Override
	public int getLocalPort() {
		return this.hashCode() % 65535 + 1;
	}

	@Override
	public SocketAddress getLocalSocketAddress() {
		return new InetSocketAddress("localhost", getLocalPort());
	}

	@Override
	public boolean getOOBInline() throws SocketException {
		return false;
	}

	@Override
	public OutputStream getOutputStream() throws IOException {
		return out;
	}

	@Override
	public int getPort() {
		return getLocalPort();
	}

	@Override
	public int getReceiveBufferSize() throws SocketException {
		return 4096;
	}

	@Override
	public SocketAddress getRemoteSocketAddress() {
		return getLocalSocketAddress();
	}

	@Override
	public boolean getReuseAddress() throws SocketException {
		return false;
	}

	@Override
	public int getSendBufferSize() throws SocketException {
		return 4096; /* dummy value */
	}

	@Override
	public int getSoLinger() throws SocketException {
		return 0;
	}

	@Override
	public int getSoTimeout() throws SocketException {
		return timeout;
	}

	@Override
	public boolean getTcpNoDelay() throws SocketException {
		return true;
	}

	@Override
	public int getTrafficClass() throws SocketException {
		return 0x02;
	}

	@Override
	public boolean isBound() {
		return true;
	}

	@Override
	public boolean isClosed() {
		return fileIn == null;
	}

	@Override
	public boolean isConnected() {
		return fileIn != null;
	}

	@Override
	public boolean isInputShutdown() {
		return fileIn == null;
	}

	@Override
	public boolean isOutputShutdown() {
		return fileOut == null;
	}

	@Override
	public void sendUrgentData(int data) throws IOException {
		throw new IOException("not supported");
	}

	@Override
	public void setKeepAlive(boolean on) throws SocketException {
	}

	@Override
	public void setOOBInline(boolean on) throws SocketException {
	}

	@Override
	public void setPerformancePreferences(int connectionTime, int latency, int bandwidth) {
	}

	@Override
	public void setReceiveBufferSize(int size) throws SocketException {
	}

	@Override
	public void setReuseAddress(boolean on) throws SocketException {
	}

	@Override
	public void setSendBufferSize(int size) throws SocketException {
	}

	@Override
	public void setSoLinger(boolean on, int linger) throws SocketException {
	}

	@Override
	public void setSoTimeout(int timeout) throws SocketException {
		trace(0, "setSoTimeout "+timeout);
		if (timeout >= 0)
			this.timeout = timeout;
	}

	@Override
	public void setTcpNoDelay(boolean on) throws SocketException {
	}

	@Override
	public void setTrafficClass(int tc) throws SocketException {
	}

	@Override
	public void shutdownInput() throws IOException {
		trace(0, "shutdownInput");
	}

	@Override
	public void shutdownOutput() throws IOException {
		trace(0, "shutdownOutput");
	}

	public boolean isInactive(long timeout) {
		return isClosed() || lastActiveTs + timeout < System.currentTimeMillis();
	}

	@Override
	public String toString() {
		return pathIn.getAbsolutePath();
	}
	
	@Override
	protected void finalize() {
		try {
			close();
		}
		catch (Exception e) {}
	}
	
	/*
	 * very simple test
	 */
	public final static void main(String[] args) throws IOException {
		FileBasedCommunication cli = new FileBasedCommunication("/tmp/.jmx/1@localhost");
		final FileBasedCommunication srv = new FileBasedCommunication(new File(cli.toString()));
		new Thread(() -> {
			while (!srv.isClosed()) {
				try {
					DataInputStream dis = new DataInputStream(srv.getInputStream());
					String s = dis.readUTF();
					System.out.println("Server did read '"+s+"'");
					DataOutputStream dos = new DataOutputStream(srv.getOutputStream());
					dos.writeUTF(s.toUpperCase());
					System.out.println("Server wrote response '"+s.toUpperCase()+"'");
				}
				catch (EOFException eof) {
					break;
				}
				catch (IOException e) {
					e.printStackTrace();
					break;
				}
			}
		}).start();
		
		DataInputStream dis = new DataInputStream(cli.getInputStream());
		DataOutputStream dos = new DataOutputStream(cli.getOutputStream());
		dos.writeUTF("Hello World");
		dos.writeUTF("Test string");
		System.err.println(dis.readUTF());
		System.err.println(dis.readUTF());
		dos.writeUTF("testing testing 1");
		System.err.println(dis.readUTF());
		dos.writeUTF("a");
		dos.writeUTF("This is slightly longer string payload which is being sent to FileBasedCommunication uppercase echo server");
		System.err.println(dis.readUTF());
		System.err.println(dis.readUTF());
		srv.close();
		cli.close();
	}
}