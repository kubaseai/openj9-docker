package sun.management.jmxremote;

import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.nio.channels.ServerSocketChannel;
import java.nio.file.Files;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.concurrent.ConcurrentHashMap;

public class FileBasedCommunicationServer extends ServerSocket implements Serializable, Comparator<File> {
	
	private static final long serialVersionUID = 1L;
	private static boolean trace = "true".equalsIgnoreCase(System.getProperty(FileBasedCommunication.class.getName()+".trace"));
	private File acceptDir = null;
	private volatile boolean running = true;
	private ConcurrentHashMap<File, FileBasedCommunication> acceptedFiles = new ConcurrentHashMap<>();
	private int timeout = 60000;

	public FileBasedCommunicationServer() throws IOException {
		acceptDir = getAcceptDir();
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				try {
					close();
				}
				catch (IOException e) {}
			}
		});
	}
	
	public void trace(String msg, boolean force) {
		if (trace || force) {
			System.out.println(msg);			
		}
	}

	synchronized public static File getAcceptDir() throws IOException {
		File f = FileBasedCommunication.getProcessCommunicationDir();
		Files.createDirectories(f.toPath());
		return f;
	}
	
	private void _cleanup() {
		File[] list = acceptDir.listFiles();
		if (list!=null) {
			for (File f : list) {
				if (f.getName().endsWith(".IN") || f.getName().endsWith(".OUT")) {
					try {
						trace("Cleanup "+f.getName(), false);
						Files.deleteIfExists(f.toPath());
					}
					catch (Exception e) {}
				}
			}
		}
	}

	@Override
	public Socket accept() throws IOException {
		while (running) {
			File[] files = acceptDir.listFiles();
			if (files!=null) {
				Arrays.sort(files, this);
				for (File f : files) {
					if (!f.getName().endsWith(".IN"))
						continue;
					if (!acceptedFiles.containsKey(f)) {
						FileBasedCommunication comm = new FileBasedCommunication(f);
						if (comm.getSoTimeout()!=timeout)
							comm.setSoTimeout(timeout);
						acceptedFiles.put(f, comm);
						return comm;
					}
				}
			}
			try {
				Thread.sleep(500);
			}
			catch (InterruptedException e) {
				break;
			}
		}
		throw new IOException("Interrupted");
	}

	@Override
	public void bind(SocketAddress endpoint, int backlog) throws IOException {
	}

	@Override
	public void bind(SocketAddress endpoint) throws IOException {
	}

	@Override
	public void close() throws IOException {
		running = false;
		trace("Closing server", false);
		Iterator<Entry<File,FileBasedCommunication>> it = acceptedFiles.entrySet().iterator();
		while (it.hasNext()) {
			Entry<File,FileBasedCommunication> en = it.next();
			en.getValue().close();
			it.remove();
		}
		
		_cleanup();
		try {
			Files.deleteIfExists(acceptDir.toPath());
		}
		catch (Exception ignore) {}
	}

	@Override
	public ServerSocketChannel getChannel() {
		throw new RuntimeException("not supported");
	}

	@Override
	public InetAddress getInetAddress() {
		return InetAddress.getLoopbackAddress();
	}

	@Override
	public int getLocalPort() {
		return 0;
	}

	@Override
	public SocketAddress getLocalSocketAddress() {
		return new InetSocketAddress(InetAddress.getLoopbackAddress(), 0);
	}

	@Override
	public synchronized int getReceiveBufferSize() throws SocketException {
		return 4096; /* dummy value */
	}

	@Override
	public boolean getReuseAddress() throws SocketException {
		return true;
	}

	@Override
	public int getSoTimeout() throws IOException {
		return timeout;
	}

	@Override
	public boolean isBound() {
		return true;
	}

	@Override
	public boolean isClosed() {
		return !running;
	}

	@Override
	public void setPerformancePreferences(int connectionTime, int latency, int bandwidth) {
	}

	@Override
	public void setReceiveBufferSize(int size) throws SocketException {
	}

	@Override
	public void setReuseAddress(boolean on) throws SocketException {
	}

	@Override
	public void setSoTimeout(int timeout) throws SocketException {
		this.timeout = timeout;
	}

	@Override
	public String toString() {
		return acceptDir.getAbsolutePath();
	}

	@Override
	public int compare(File o1, File o2) {
		try {
			long l = Files.readAttributes(o1.toPath(), BasicFileAttributes.class).creationTime().toMillis();
			l -= Files.readAttributes(o2.toPath(), BasicFileAttributes.class).creationTime().toMillis();
			return (int)l;	
		}
		catch (Exception e) {}
		return 0;
	}
}
