package sun.management.jmxremote;

import java.io.IOException;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.rmi.server.RMIClientSocketFactory;
import java.rmi.server.RMIServerSocketFactory;
import java.rmi.server.RMISocketFactory;

/**
 * JMX can be enabled via Attach API with TCP/IP transport by default
 * because R in RMI stands for Remote. But what if we have 
 * 1000 scaled docker containers to be monitored with JMX?
 * Each one instance (including replicas) needs to have unique
 * TCP/IP port mapping maintained. Local MI would be better.
 * 
 * Attach API using shared volume of /tmp
 * to list Virtual Machines and access them with JMX should use files.
 * FileBasedCommunication class pretends to be a Socket but uses files.
 * Please do "mount -t tmpfs none /tmp/.jmx", because of fsync.
 * 
 * This is just a PoC to be used with Eclipse OpenJ9.
 * If you want something with industrial quality and Unix sockets
 * you need to wait for Oracle. Unix sockets are not cross platform,
 * they need native C/C++ code. I know POSIX but wanted pure Java.
 * 
 * This patch probably is "write once, run everywhere", 
 * but wasn't tested on Windows 2019.
 * I needed this for Tibco BusinessWorks 5.13 custom container edition.
 * 
 * ConnectorBootstrap can pass serialized instance of this factory
 * to the client, then client can create socket.
 * 
 * @author jakub.jozwicki@gmail.com
 *
 */
public class FileRMISocketFactory extends RMISocketFactory implements RMIClientSocketFactory, RMIServerSocketFactory, Serializable {
	
	private static final long serialVersionUID = 1L;
	private FileBasedCommunicationServer fbcs = null;

	private String acceptDir = null;

	public FileRMISocketFactory() throws IOException {
		fbcs = new FileBasedCommunicationServer();
		acceptDir = fbcs.toString();
	}
	
	public FileRMISocketFactory(String name) {
		acceptDir = name;
	}
	
	@Override
	public Socket createSocket(String host, int port) throws IOException {
		return new FileBasedCommunication(acceptDir);
	}

	@Override
	public ServerSocket createServerSocket(int port) throws IOException {
		if (fbcs==null)
			throw new IOException("Invalid usage of factory");
		fbcs.trace("createServerSocket "+port, false);
		return fbcs;
	}
	
	public String toString() {
		return acceptDir;
	}

	public FileRMISocketFactory getClientSocketFactory() {
		return new FileRMISocketFactory(acceptDir);
	}
}
